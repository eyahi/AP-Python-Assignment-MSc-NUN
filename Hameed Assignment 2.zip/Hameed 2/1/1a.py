class Restaurant:
    def __init__(self, restaurant_name, cuisine_type):
        self.restaurant_name = restaurant_name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):
        print(f"Restaurant Name: {self.restaurant_name}")
        print(f"Cuisine Type: {self.cuisine_type}")

    def open_restaurant(self):
        print(f"{self.restaurant_name} is open!")

# Instance and method calls
restaurant = Restaurant("Fine Dining", "Italian")
print("Individual Attributes:")
print(f"Restaurant Name: {restaurant.restaurant_name}")
print(f"Cuisine Type: {restaurant.cuisine_type}")
print("\nMethod Calls:")
restaurant.describe_restaurant()
restaurant.open_restaurant()

# Instances and method calls for three different restaurants
restaurant1 = Restaurant("Cafe de Paris", "French")
restaurant2 = Restaurant("Spice Bazaar", "Indian")
restaurant3 = Restaurant("Sushi Haven", "Japanese")

print("\nDescriptions for Different Restaurants:")
restaurant1.describe_restaurant()
restaurant2.describe_restaurant()
restaurant3.describe_restaurant()